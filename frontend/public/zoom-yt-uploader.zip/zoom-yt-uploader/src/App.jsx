import { useState, useEffect } from 'react'
import { UploadCloud, Settings, PlayCircle, Video, CheckCircle, RefreshCw, Key, LogIn, Lock } from 'lucide-react'

function App() {
  const [activeTab, setActiveTab] = useState('upload') // 'upload' or 'settings'
  const [meetingId, setMeetingId] = useState('')
  const [status, setStatus] = useState('idle') // idle, uploading, completed
  const [progressData, setProgressData] = useState({ stage: '', percent: 0 })
  const [youtubeUrl, setYoutubeUrl] = useState('')
  const [isYoutubeAuthed, setIsYoutubeAuthed] = useState(false)

  // Settings state
  const [zoomAccountId, setZoomAccountId] = useState('')
  const [zoomClientId, setZoomClientId] = useState('')
  const [zoomClientSecret, setZoomClientSecret] = useState('')
  const [youtubeClientId, setYoutubeClientId] = useState('')
  const [youtubeClientSecret, setYoutubeClientSecret] = useState('')

  useEffect(() => {
    // Load settings from electron
    if (window.electronAPI) {
      window.electronAPI.getSettings().then(settings => {
        if (settings) {
          setYoutubeClientId(settings.youtubeClientId || '')
          setYoutubeClientSecret(settings.youtubeClientSecret || '')
        }
      })

      window.electronAPI.checkYoutubeAuth().then(isAuthed => {
        setIsYoutubeAuthed(isAuthed)
      })

      window.electronAPI.onUploadProgress((data) => {
        setProgressData(data)
        if (data.percent === 100) {
          setStatus('completed')
        }
      })
    }
  }, [activeTab])

  const saveSettings = () => {
    if (window.electronAPI) {
      window.electronAPI.saveSettings({
        youtubeClientId, youtubeClientSecret
      })
      alert('Settings saved successfully!')
    }
  }

  const handleGoogleLogin = async () => {
    if (!youtubeClientId || !youtubeClientSecret) {
      alert('Please save your Google Client ID and Secret first.')
      return
    }
    saveSettings()
    try {
      await window.electronAPI.authGoogle()
      alert('Successfully authenticated with Google!')
      setIsYoutubeAuthed(true)
    } catch (err) {
      alert('Authentication failed: ' + err.message)
    }
  }

  const handleUpload = async () => {
    if (!meetingId) {
      alert('Please enter a Zoom Meeting ID')
      return
    }
    if (!isYoutubeAuthed) {
      alert('Please authenticate with YouTube in Settings first.')
      setActiveTab('settings')
      return
    }

    setStatus('uploading')
    setProgressData({ stage: 'Initializing...', percent: 0 })
    
    if (window.electronAPI) {
      try {
        const result = await window.electronAPI.startUploadProcess({ meetingId })
        if (result.success) {
          setYoutubeUrl(result.youtubeUrl)
        }
      } catch (err) {
        alert('Upload failed: ' + err.message)
        setStatus('idle')
      }
    }
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      {/* Custom Title Bar */}
      <div className="h-10 bg-slate-800/50 backdrop-blur-md flex items-center px-4 titlebar-drag border-b border-white/5">
        <div className="flex items-center gap-2">
          <PlayCircle className="w-5 h-5 text-red-500" />
          <span className="font-semibold text-sm tracking-wide">Zoom to YouTube Uploader</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-64 bg-slate-800/30 border-r border-white/5 p-4 flex flex-col gap-2">
          <button 
            onClick={() => setActiveTab('upload')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 no-drag ${activeTab === 'upload' ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <UploadCloud className="w-5 h-5" />
            <span className="font-medium">Upload Video</span>
          </button>
          
          <button 
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 no-drag ${activeTab === 'settings' ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <Settings className="w-5 h-5" />
            <span className="font-medium">Settings</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-8 overflow-y-auto relative no-drag">
          {/* Subtle background glow */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-[100px] pointer-events-none"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-red-500/5 rounded-full blur-[100px] pointer-events-none"></div>

          <div className="max-w-2xl mx-auto relative z-10">
            {activeTab === 'upload' && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="text-center space-y-2 mb-10">
                  <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">Auto Uploader</h1>
                  <p className="text-slate-400">Transfer Zoom recordings directly to YouTube Unlisted.</p>
                </div>

                <div className="bg-slate-800/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl">
                  <div className="space-y-5">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">Zoom Meeting ID</label>
                      <div className="relative">
                        <Video className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                        <input 
                          type="text" 
                          value={meetingId}
                          onChange={(e) => setMeetingId(e.target.value)}
                          disabled={status !== 'idle'}
                          placeholder="e.g. 123 456 7890"
                          className="w-full bg-slate-900/50 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                        />
                      </div>
                      <p className="text-xs text-slate-500 mt-2">Enter the Zoom Meeting ID (numbers only, spaces are ignored) to automatically fetch and upload the recording.</p>
                    </div>

                    {status === 'idle' && (
                      <button 
                        onClick={handleUpload}
                        className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold py-3.5 rounded-xl shadow-lg shadow-blue-500/25 transition-all transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2"
                      >
                        <UploadCloud className="w-5 h-5" />
                        Start Transfer
                      </button>
                    )}

                    {status === 'uploading' && (
                      <div className="bg-slate-900/50 border border-blue-500/30 rounded-xl p-5 space-y-4">
                        <div className="flex items-center justify-between text-sm font-medium">
                          <span className="text-blue-400 flex items-center gap-2">
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            {progressData.stage}
                          </span>
                          <span className="text-slate-300">{progressData.percent}%</span>
                        </div>
                        <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 transition-all duration-300 ease-out"
                            style={{ width: `${progressData.percent}%` }}
                          ></div>
                        </div>
                      </div>
                    )}

                    {status === 'completed' && (
                      <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-6 text-center space-y-4">
                        <div className="flex justify-center">
                          <CheckCircle className="w-12 h-12 text-green-500" />
                        </div>
                        <h3 className="text-xl font-semibold text-green-400">Transfer Complete!</h3>
                        <div className="bg-slate-900/80 p-3 rounded-lg flex items-center justify-between border border-white/5">
                          <span className="text-slate-300 text-sm truncate mr-4">{youtubeUrl}</span>
                          <button 
                            onClick={() => navigator.clipboard.writeText(youtubeUrl)}
                            className="px-4 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm font-medium rounded-md transition-colors"
                          >
                            Copy
                          </button>
                        </div>
                        <button 
                          onClick={() => {
                            setStatus('idle');
                            setMeetingId('');
                            setYoutubeUrl('');
                            setProgressData({stage: '', percent: 0});
                          }}
                          className="text-sm text-slate-400 hover:text-white transition-colors mt-2"
                        >
                          Upload Another Video
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="mb-6 flex justify-between items-end">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-100">Configuration</h2>
                    <p className="text-slate-400 text-sm mt-1">Configure your API credentials here.</p>
                  </div>
                  <button 
                    onClick={saveSettings}
                    className="bg-blue-600 hover:bg-blue-500 text-white font-medium py-2 px-6 rounded-xl shadow-lg shadow-blue-500/20 transition-all"
                  >
                    Save Settings
                  </button>
                </div>

                <div className="bg-slate-800/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-xl space-y-5">
                  <div className="flex items-center gap-2 mb-4 border-b border-white/10 pb-3">
                    <Video className="w-5 h-5 text-blue-400" />
                    <h3 className="text-lg font-semibold">Zoom Server-to-Server OAuth</h3>
                  </div>
                  <p className="text-sm text-slate-400">All 8 Zoom accounts have been securely hardcoded into the application. The system will automatically search across all accounts to find your recording.</p>
                </div>

                <div className="bg-slate-800/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-xl space-y-5">
                  <div className="flex items-center gap-2 mb-4 border-b border-white/10 pb-3">
                    <PlayCircle className="w-5 h-5 text-red-500" />
                    <h3 className="text-lg font-semibold flex-1">YouTube Data API</h3>
                    {isYoutubeAuthed ? (
                      <span className="flex items-center gap-1 text-xs font-medium bg-green-500/20 text-green-400 px-3 py-1.5 rounded-full">
                        <CheckCircle className="w-3 h-3" /> Authenticated
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs font-medium bg-red-500/20 text-red-400 px-3 py-1.5 rounded-full">
                        <Lock className="w-3 h-3" /> Not Authenticated
                      </span>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">OAuth Client ID</label>
                    <input 
                      type="text" 
                      value={youtubeClientId}
                      onChange={(e) => setYoutubeClientId(e.target.value)}
                      placeholder="e.g. 509557246805-...apps.googleusercontent.com"
                      className="w-full bg-slate-900/50 border border-white/10 rounded-xl py-2.5 px-4 text-slate-200 focus:outline-none focus:border-red-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">OAuth Client Secret</label>
                    <input 
                      type="password" 
                      value={youtubeClientSecret}
                      onChange={(e) => setYoutubeClientSecret(e.target.value)}
                      placeholder="e.g. GOCSPX-y3XHh6q..."
                      className="w-full bg-slate-900/50 border border-white/10 rounded-xl py-2.5 px-4 text-slate-200 focus:outline-none focus:border-red-500 transition-colors"
                    />
                  </div>

                  {!isYoutubeAuthed && (
                    <button 
                      onClick={handleGoogleLogin}
                      className="w-full mt-4 bg-slate-700 hover:bg-slate-600 text-white font-medium py-3 rounded-xl flex items-center justify-center gap-2 transition-all border border-slate-600"
                    >
                      <LogIn className="w-5 h-5" />
                      Login with YouTube Account
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
