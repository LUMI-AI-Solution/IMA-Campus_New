const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // We will add Zoom and YouTube API handlers here
  startUploadProcess: (data) => ipcRenderer.invoke('start-upload-process', data),
  onUploadProgress: (callback) => ipcRenderer.on('upload-progress', (_event, data) => callback(data)),
  saveSettings: (settings) => ipcRenderer.invoke('save-settings', settings),
  getSettings: () => ipcRenderer.invoke('get-settings'),
  authGoogle: () => ipcRenderer.invoke('auth-google'),
  checkYoutubeAuth: () => ipcRenderer.invoke('check-youtube-auth')
});
