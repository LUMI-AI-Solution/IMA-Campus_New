const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const { google } = require('googleapis');
const http = require('http');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1000,
    height: 700,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
    titleBarStyle: 'hiddenInset',
    backgroundColor: '#0f172a'
  });

  if (process.env.NODE_ENV === 'development') {
    mainWindow.loadURL('http://localhost:5180');
    // mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});

// Settings Management
const settingsPath = path.join(app.getPath('userData'), 'settings.json');

ipcMain.handle('get-settings', async () => {
  if (fs.existsSync(settingsPath)) {
    return JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
  }
  return {};
});

ipcMain.handle('save-settings', async (event, settings) => {
  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
  return true;
});

// Google OAuth Setup
ipcMain.handle('auth-google', async (event) => {
  const settings = JSON.parse(fs.existsSync(settingsPath) ? fs.readFileSync(settingsPath, 'utf8') : '{}');
  
  if (!settings.youtubeClientId || !settings.youtubeClientSecret) {
    throw new Error('Please save your Google Client ID and Secret in settings first.');
  }

  const oauth2Client = new google.auth.OAuth2(
    settings.youtubeClientId,
    settings.youtubeClientSecret,
    'http://localhost:3000/oauth2callback'
  );

  return new Promise((resolve, reject) => {
    const server = http.createServer(async (req, res) => {
      try {
        if (req.url.indexOf('/oauth2callback') > -1) {
          const qs = new URL(req.url, 'http://localhost:3000').searchParams;
          res.end('Authentication successful! Please return to the app.');
          server.destroy();
          
          const { tokens } = await oauth2Client.getToken(qs.get('code'));
          oauth2Client.setCredentials(tokens);
          
          settings.youtubeTokens = tokens;
          fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
          resolve(true);
        }
      } catch (e) {
        reject(e);
      }
    });
    
    import('server-destroy').then(({default: enableDestroy}) => {
      enableDestroy(server);
      server.listen(3000, () => {
        const authUrl = oauth2Client.generateAuthUrl({
          access_type: 'offline',
          scope: ['https://www.googleapis.com/auth/youtube.upload']
        });
        shell.openExternal(authUrl);
      });
    }).catch(reject);
  });
});

ipcMain.handle('check-youtube-auth', async () => {
  const settings = JSON.parse(fs.existsSync(settingsPath) ? fs.readFileSync(settingsPath, 'utf8') : '{}');
  return !!settings.youtubeTokens;
});

// Helper for Zoom OAuth
async function getZoomToken(accountId, clientId, clientSecret) {
  const tokenUrl = `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${accountId}`;
  const authHeader = 'Basic ' + Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  
  const response = await axios.post(tokenUrl, {}, {
    headers: { 'Authorization': authHeader }
  });
  return response.data.access_token;
}

const ZOOM_ACCOUNTS = [
  { name: "Acc 01", accountId: "nsKzuoSbQLqeEKFO25W3QA", clientId: "Lzn79CR2W2LLKVAm9thw", clientSecret: "cs0qQYhl3HVKRh9liOmA8SNz3217njHY" },
  { name: "Acc 02", accountId: "nsKzuoSbQLqeEKFO25W3QA", clientId: "zdp67ASFQ8yp4Y6YXBB20Q", clientSecret: "YAA1RWgc9pEq7QMhKYc2xhYITNkcDQ3K" },
  { name: "Acc 03", accountId: "nsKzuoSbQLqeEKFO25W3QA", clientId: "NY0LYloxTZGhwi2l0pcpTQ", clientSecret: "A898Z1ZJsebK6uY3Pf5TRbxgo0JPpOSv" },
  { name: "Acc 04", accountId: "nsKzuoSbQLqeEKFO25W3QA", clientId: "iU2c7XYURSyY_yIySVEuVg", clientSecret: "KXHh0mXb0KMJ5PqCN4n7OBbEnhXCTQ08" },
  { name: "Acc 05", accountId: "nsKzuoSbQLqeEKFO25W3QA", clientId: "gKXNiK2jT42W2pkP11ncAg", clientSecret: "PtVybT7aA4wNQELTJMhL63awUOFv9dpn" },
  { name: "Acc 06", accountId: "nsKzuoSbQLqeEKFO25W3QA", clientId: "jheRyAaOQ0ugGeWjoYvQFQ", clientSecret: "GuYPH13R0eJnkqkWRZX8nAC1iC8IWp8z" },
  { name: "Acc 07", accountId: "nsKzuoSbQLqeEKFO25W3QA", clientId: "I1ko4YsDTUCpGrcobIfFrA", clientSecret: "NKKghbWe5t2PX95Dov3xpq1G58lvkEj7" },
  { name: "Acc 08", accountId: "nsKzuoSbQLqeEKFO25W3QA", clientId: "Cv5XlndDTVKNY6v_pYg37g", clientSecret: "H1TNcXkr4SENQ3236jFIyzAnctA19dYZ" }
];

// Main Process
ipcMain.handle('start-upload-process', async (event, data) => {
  const { meetingId } = data;
  const settings = JSON.parse(fs.existsSync(settingsPath) ? fs.readFileSync(settingsPath, 'utf8') : '{}');
  const cleanMeetingId = meetingId.replace(/[-\s]+/g, '');

  try {
    event.sender.send('upload-progress', { stage: 'Searching across Zoom Accounts...', percent: 5 });
    
    let meetingRes = null;
    let zoomToken = null;
    let mp4File = null;

    for (const acc of ZOOM_ACCOUNTS) {
      try {
        const token = await getZoomToken(acc.accountId, acc.clientId, acc.clientSecret);
        const res = await axios.get(`https://api.zoom.us/v2/meetings/${cleanMeetingId}/recordings`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        const recordingFiles = res.data.recording_files || [];
        const mp4 = recordingFiles.find(f => f.file_type === 'MP4');
        
        if (mp4) {
          meetingRes = res;
          zoomToken = token;
          mp4File = mp4;
          event.sender.send('upload-progress', { stage: `Found recording in ${acc.name}!`, percent: 15 });
          break; // Stop searching once found
        }
      } catch (e) {
        // Ignored, try next account
      }
    }

    if (!mp4File) {
      throw new Error('No MP4 recording found for this Meeting ID in any Zoom account.');
    }

    // 3. Download MP4
    event.sender.send('upload-progress', { stage: 'Downloading Video...', percent: 30 });
    const downloadUrl = `${mp4File.download_url}?access_token=${zoomToken}`;
    const tempFilePath = path.join(app.getPath('temp'), `zoom_${cleanMeetingId}.mp4`);
    
    const writer = fs.createWriteStream(tempFilePath);
    const downloadRes = await axios({
      url: downloadUrl,
      method: 'GET',
      responseType: 'stream'
    });

    const totalLength = downloadRes.headers['content-length'];
    let downloaded = 0;
    
    downloadRes.data.on('data', (chunk) => {
      downloaded += chunk.length;
      const percent = Math.floor((downloaded / totalLength) * 30) + 30; // 30% to 60%
      event.sender.send('upload-progress', { stage: `Downloading Video (${(downloaded/1024/1024).toFixed(1)}MB)`, percent });
    });

    downloadRes.data.pipe(writer);
    await new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });

    // 4. Upload to YouTube
    event.sender.send('upload-progress', { stage: 'Uploading to YouTube...', percent: 65 });
    
    const oauth2Client = new google.auth.OAuth2(
      settings.youtubeClientId,
      settings.youtubeClientSecret,
      'http://localhost:3000/oauth2callback'
    );
    oauth2Client.setCredentials(settings.youtubeTokens);

    const youtube = google.youtube({ version: 'v3', auth: oauth2Client });
    
    const fileSize = fs.statSync(tempFilePath).size;
    
    const res = await youtube.videos.insert({
      part: 'snippet,status',
      requestBody: {
        snippet: {
          title: meetingRes.data.topic || `Zoom Class Recording`,
          description: `Class recorded on ${new Date(meetingRes.data.start_time).toLocaleString()}`
        },
        status: {
          privacyStatus: 'unlisted',
          selfDeclaredMadeForKids: false
        }
      },
      media: {
        body: fs.createReadStream(tempFilePath)
      }
    }, {
      onUploadProgress: evt => {
        const percent = Math.floor((evt.bytesRead / fileSize) * 35) + 65; // 65% to 100%
        event.sender.send('upload-progress', { stage: `Uploading to YouTube (${(evt.bytesRead/1024/1024).toFixed(1)}MB)`, percent });
      }
    });

    // Cleanup
    fs.unlinkSync(tempFilePath);

    event.sender.send('upload-progress', { stage: 'Completed', percent: 100 });
    return { success: true, youtubeUrl: `https://youtu.be/${res.data.id}` };

  } catch (error) {
    console.error(error);
    const errorMsg = error.response?.data?.message || error.message || 'Unknown error occurred';
    throw new Error(errorMsg);
  }
});
